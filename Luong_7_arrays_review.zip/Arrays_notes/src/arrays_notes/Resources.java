/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays_notes;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mluong
 */
public class Resources extends Luong_7_projects {
    //public int hi;
    public static boolean inventory = false;
    public static boolean rifle = false;
    public static boolean blade = false;
    public static boolean spear = false;//will allow repeat of tile and also for inventory purposes
    public static boolean knife = false;
    public static boolean equipspear = false;
    public static boolean equiprifle = false;
    public static boolean equipblade = false;
    public static boolean equipknife = false;
    
    /*public Resources(int a, int b) {
        this.hi = a;
    }*/
    
    public static void inventorycheckup() {
        if(numbersX == inventorycheckx && numbersY == inventorychecky) {
            System.out.println("You have accessed an inventory check system...\n");
            System.out.println("What would you like to do?\n\n\n");
            System.out.println("To check your health, press (H).\n ");
            System.out.println("To check how many points you have gotten, press (P).\n");
            System.out.println("To check how many treasure boxes are left on the map, press (T)\n");
            System.out.println("To equip a new item, press (I)\n");
            System.out.println("To exit this inventory, press (X)\n");
            inventory = true;
            enter = recorded.nextLine();
        } else if(numbersX == inventorycheck2x && numbersY == inventorycheck2y) {
            System.out.println("You have accessed an inventory check system...\n");
            System.out.println("What would you like to do?\n\n\n");
            System.out.println("To check your health, press (H).\n ");
            System.out.println("To check how many points you have gotten, press (P).\n");
            System.out.println("To check how many treasure boxes are left on the map, press (T)\n");
            System.out.println("To equip a new item, press (I)\n");
            System.out.println("To exit this inventory, press (X)\n");
            inventory = true;
            enter = recorded.nextLine();
        } else if(numbersX == inventorycheck3x && numbersY == inventorycheck3y) {
            System.out.println("You have accessed an inventory check system...\n");
            System.out.println("What would you like to do?\n\n\n");
            System.out.println("To check your health, press (H).\n ");
            System.out.println("To check how many points you have gotten, press (P).\n");
            System.out.println("To check how many treasure boxes are left on the map, press (T)\n");
            System.out.println("To equip a new item, press (I)\n");
            System.out.println("To exit this inventory, press (X)\n");
            inventory = true;
            enter = recorded.nextLine();
        } else if(numbersX == inventorycheck4x && numbersY == inventorycheck4y) {
            System.out.println("You have accessed an inventory check system...\n");
            System.out.println("What would you like to do?\n\n\n");
            System.out.println("To check your health, press (H).\n ");
            System.out.println("To check how many points you have gotten, press (P).\n");
            System.out.println("To check how many treasure boxes are left on the map, press (T)\n");
            System.out.println("To equip a new item, press (I)\n");
            System.out.println("To exit this inventory, press (X)\n");
            inventory = false;
            enter = recorded.nextLine();
        }
        
        if(inventory) {
            if(enter.contains("H") || enter.contains("h")) {
                System.out.println("You have accessed the health menu...\n\n\n");
                healthmenu();
            } else if(enter.contains("P") || enter.contains("p")) {
                System.out.println("Checking total points...\n\n\n");
                pointvaluemenu();
            } else if(enter.contains("T") || enter.contains("t")) {
                System.out.println("You have opened the map menu...\n\n\n");
                treasuremenu();
            } else if(enter.contains("X") || enter.contains("x")) {
                System.out.println("Have a nice day!");
            } else if(enter.contains("I") || enter.contains("i")) {
                System.out.println("You have accessed the weapon bag...\n\n\n");
                checkingweapons();
            }
            else {
                return;
            }
        }
    }
    
    public static void healthmenu() {
        System.out.println("Your current health is " + playerhealth + " HP.\n\n\n");
    }
    
    public static void pointvaluemenu() {
        System.out.println("You currently have " + points + " points.\n\n\n");
    }
    
    public static void treasuremenu() {
        System.out.println("Treasure map one is on row " + treasurex + " and column " + treasurey + ".\n\n");
        System.out.println("Treasure map two is on row " + treasure2x + " and column " + treasure2y + ".\n\n");
    }
    
    public static void checkingweapons() {
        if(equipspear) {
            System.out.println("You are currently equipped with a spear that deals up to 50 HP.");
        } else if(equipblade) {
            System.out.println("You are currently equipped with a blade that deals up to 125 HP.");
        } else if(equiprifle) {
            System.out.println("You are currently equipped with a rifle that deals up to 100 HP.");
        } else if(equipknife) {
            System.out.println("You are currently equipped with a knife that deals up to 30 HP.");
        }
        
        for(int h = 0; h < 5; h++) {
            System.out.println("");
        }
        
        System.out.println("Do you want to equip another weapon instead?\n");
        enter = recorded.nextLine();
        if(enter.contains("Y") || enter.contains("y")) {
            System.out.println("Here are all the weapons you've collected...\n\n\n");
            if(spear) {
                System.out.println("You have a spear.");
            } 
            if(knife) {
                System.out.println("You have a knife.");
            } 
            if(blade) {
                System.out.println("You have a blade.");
            }
            if(rifle) {
                System.out.println("You have a rifle.");
            }
            
            System.out.println("Which weapon do you want to equip?\n");
            
        }
    }
    
    public static void equipped() {
        if(rifle) {
            System.out.println("Press (R) to grab the rifle.\n");
        } 
        if(blade) {
            System.out.println("Press (B) to grab the blade.\n ");
        }
        if(knife) {
            System.out.println("Press (K) to grab the knife.\n");
        }
        if(spear) {
            System.out.println("Press (S) to grab the spear.\n");
        }

        System.out.println("Press (X) to exit the menu.\n");
        
        if(!rifle && !blade && !knife && !spear) {
            System.out.println("Looks like that you don't have any weapons available yet.");
            enter = "X";
        }
        
        enter = recorded.nextLine();
        if(enter.contains("R") && !equiprifle && rifle) {
            System.out.println("You have equipped the rifle.");
            equiprifle = true;
            equipspear = false;
            equipknife = false;
            equipblade = false;
        } else if(enter.contains("B") && !equipblade && blade)  {
            System.out.println("You have equipped the blade.");
            equipblade = true;
            equiprifle = false;
            equipspear = false;
            equipknife = false;
        } else if(enter.contains("K") && !equipknife && knife)  {
            System.out.println("You have equipped the knife.");
            equipknife = true;
            equipblade = false;
            equiprifle = false;
            equipspear = false;
        } else if(enter.contains("S") && !equipspear && spear) {
            System.out.println("You have equipped the spear.");
            equipspear = true;
            equipknife = false;
            equipblade = false;
            equiprifle = false;
        } else if(enter.contains("X")) {
            System.out.println("Player exits the menu");
        } else {
            System.out.println("Please make sure you are doing this right...\n\n\n");
            equipped();
        }
    }
    
    public static void weapons() {
       if(numbersX == spearx && numbersY == speary && !spear) {
           System.out.println("There's a spear in front of you \n do you want to pick it up?");
           enter = recorded.nextLine();
           if(enter.contains("y") || enter.contains("Y")) {
               System.out.println("Player uses the spear.");
               spear = true;
               equipspear = true;
               equipblade = false;
               equipknife = false;
               equiprifle = false;
           } else {
               System.out.println("Player put the spear back where he found it...\n");
               spear = false;
           }
       } else if(numbersX == bladex && numbersY == bladey && !blade) {
           System.out.println("There's a large blade stuck between two rocks.\n");
           System.out.println("Do you want to pick it up?");
           enter = recorded.nextLine();
           if(enter.contains("y") || enter.contains("Y")) {
               System.out.println("Player pulls the blade out of the ground.\n");
               System.out.println("Player equips the blade.");
               blade = true;
               equipblade = true;
               equipspear = false;
               equipknife = false;
               equiprifle = false;
           } else {
               System.out.println("Player puts the blade back between the rocks and carries on...\n");
               blade = false;
           }
       } else if(numbersX == riflex && numbersY == rifley && !blade) {
           System.out.println("There's a rifle that is sitting by the grass that seems to be loaded.\n");
           System.out.println("Do you want to pick it up?");
           enter = recorded.nextLine();
           if(enter.contains("y") || enter.contains("Y")) {
               System.out.println("Player grabs the rifle and pulls the trigger, it is loaded...\n\n");
               System.out.println("Player is equipped with the rifle.");
               rifle = true;
               equiprifle = true;
               equipspear = false;
               equipblade = false;
               equipknife = false;
           } else {
               System.out.println("You ignore the rifle and continue on your quest...\n\n\n");
               rifle = false;
           }
       } else if(numbersX == knifex && numbersY == knifey && !knife) {
           System.out.println("You see a knife stuck between a tree.\n");
           System.out.println("Do you want to retrieve it?\n");
           enter = recorded.nextLine(); 
           if(enter.contains("y") || enter.contains("Y")) {
               System.out.println("You pulled the knife off of the tree...\n");
               System.out.println("Player is equipped with the knife...\n\n\n");
               knife = true;
               equipknife = true;
               equipspear = false;
               equipblade = false;
               equiprifle = false;
           } else {
               System.out.println("You leave the knife there and continue on your journey...\n\n\n");
               knife = false;
           }
       } 
    }
    
    public static void attacking() {
        /* Use parentheses to format logical conditions*/
        if((N && enemyS) || (S && enemyN) || (W && enemyE) || (E && enemyW) || 
                (N && enemy3S) || (S && enemy3N) || (E && enemy3W) || (W && enemy3E)) { 
            if(equiprifle) {
                damage = rand.nextInt(50) + 50;// 50 to 100 damage
                System.out.println("Player pulled the trigger and weakened the foe by " + damage + " HP.");
                Enemy.setEnemyhealth(Enemy.getEnemyhealth() - damage);
            } else if(equipblade) {
                damage = rand.nextInt(50) + 75;//75 to 125 damage
                System.out.println("You slashed your opponent...\n\n\n");
                System.out.println("Opponent takes " + damage + " HP.");
                Enemy.setEnemyhealth(Enemy.getEnemyhealth() - damage);
            } else if(equipknife) {
                damage = rand.nextInt(15) + 15; // 15 to 30 damage
                System.out.println("You pulled out your knife and lunged...\n\n\n");
                System.out.println("You inflicted " + damage + " HP." );
                Enemy.setEnemyhealth(Enemy.getEnemyhealth() - damage);
            } else if(equipspear) {
                damage = rand.nextInt(25) + 25;// 25 to 50 damage
                System.out.println("You punctured the black coat's skin and inflicted " + damage + " HP");
                Enemy.setEnemyhealth(Enemy.getEnemyhealth() - damage);
            } else {
                System.out.println("Looks like you haven't equipped any weapons yet.\n");
                System.out.println("Check your bag when you arrive at a resource station.\n\n");
            } 
        } else {
            System.out.println("You can't attack from behind!\n");
            System.out.println("Better luck next time!");
        }
    }
    
    public static void wintext() {
            System.out.println("______  _                             _    _  _");             
            System.out.println("| ___ \\| |                           | |  | |(_)");            
            System.out.println("| |_/ /| |  __ _  _   _   ___  _ __  | |  | | _  _ __   ___"); 
            System.out.println("|  __/ | | / _` || | | | / _ \\| '__| | |/\\| || || '_ \\ / __|");
            System.out.println("| |    | || (_| || |_| ||  __/| |    \\  /\\  /| || | | |\\__ \\");
            System.out.println("\\_|    |_| \\__,_| \\__, | \\___||_|     \\/  \\/ |_||_| |_||___/");
            System.out.println("                  __/ |                                    ");
            System.out.println("                 |___/                                     ");
        
    }
    
    public static void losetext() {
    System.out.println("  ______       _____      __    __      _____       _____      _     _      _____    __ __");    
    System.out.println(" /_/\\___\\     /\\___/\\    /_/\\  /\\_\\   /\\_____\\     ) ___ (    /_/\\ /\\_\\   /\\_____\\  /_/\\__/\\");  
    System.out.println(" ) ) ___/    / / _ \\ \\   ) ) \\/ ( (  ( (_____/    / /\\_/\\ \\   ) ) ) ( (  ( (_____/  ) ) ) ) )"); 
    System.out.println("/_/ /  ___   \\ \\(_)/ /  /_/ \\  / \\_\\  \\ \\__\\     / /_/ (_\\ \\ /_/ / \\ \\_\\  \\ \\__\\   /_/ /_/_/");  
    System.out.println("\\ \\ \\_/\\__\\  / / _ \\ \\  \\ \\ \\\\// / /  / /__/_    \\ \\ )_/ / / \\ \\ \\_/ / /  / /__/_  \\ \\ \\ \\ \\");  
    System.out.println(" )_)  \\/ _/ ( (_( )_) )  )_) )( (_(  ( (_____\\    \\ \\/_\\/ /   \\ \\   / /  ( (_____\\  )_) ) \\ \\"); 
    System.out.println(" \\_\\____/    \\/_/ \\_\\/   \\_\\/  \\/_/   \\/_____/     )_____(     \\_\\_/_/    \\/_____/  \\_\\/ \\_\\/");     
        
    }
    
    public static void timer(int a) {
        try {
            Thread.sleep(a);
        } catch (InterruptedException ex) {
            Logger.getLogger(Resources.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void intro() {
        System.out.println("You woke up from your slumber only to realize that your worst nightmare was real...\n");
        timer(3000);
        System.out.println("You are stuck in a virtual world where you have to escape the black and red coats.\n");
        timer(3000);
        System.out.println("Who knows how long you are going to be in here?\n");
        timer(3000);
        System.out.println("The only thing left to do is to try to find the hidden treasures...\n");
        timer(3000);
        System.out.println("You can move N, S, E, W, NW, SW, SE, and NE.\n");
        timer(3000);
        System.out.println("There are 4 inventory check regions that you will tell you more...\n");
        timer(3000);
        System.out.println("There are also 4 weapons ad the prize is hidden somewhere.\n");
        timer(3000);
        System.out.println("Are you ready to begin your adventure...\n");
        timer(3000);
        introbanner();
        System.out.println("Here we go again...");
        timer(2400);
    }
    
    public static void introbanner() {
        System.out.println("  #####  ####### ### ####### #######     #     #  ###  #     # ");
        System.out.println(" #     # #        #       #  #           #     #   #   ##   ## ");
        System.out.println(" #       #        #      #   #           #     #   #   # # # # ");
        System.out.println("  #####  #####    #     #    #####       #######   #   #  #  # ");
        System.out.println("      #  #        #    #     #           #     #   #   #     # ");
        System.out.println(" #    #  #        #   #      #           #     #   #   #     # ");
        System.out.println(" #####   ####### ### ####### #######     #     #  ###  #     # ");
    }
    
    public static void pointsystem() {
        System.out.println("You need 100 points to get to the next level...\n");
        timer(100);
        System.out.println("You have " + points + " points.");
        if(points < 100) {
            lowpoints();
            timer(4000);
            System.out.println("You grabbed the treasure and now have enough points to go to the next level...\n");
        } else if(points >= 100) {
            highpoints();
            timer(4000);
            System.out.println("You grabbed the treasure but not enough points to go to the next level...\n");
        }
    } 
    
    public static void highpoints() {
        System.out.println("#     #  #######  #     #      #######  #####   #####     #    ######  ####### ######  ");
        System.out.println(" #   #   #     #  #     #      #       #     # #     #   # #   #     # #       #     # ");
        System.out.println("  # #    #     #  #     #      #       #       #        #   #  #     # #       #     # ");
        System.out.println("   #     #     #  #     #      #####    #####  #       #     # ######  #####   #     # ");
        System.out.println("   #     #     #  #     #      #             # #       ####### #       #       #     # ");
        System.out.println("   #     #     #  #     #      #       #     # #     # #     # #       #       #     # ");
        System.out.println("   #     #######   #####       #######  #####   #####  #     # #       ####### ######  ");
    }
    
    public static void lowpoints() {
        System.out.println("   #####   #######  #     #   #####   #    # ");
        System.out.println("  #     #     #     #     #  #     #  #   #  ");
        System.out.println("  #           #     #     #  #        #  #   ");
        System.out.println("   #####      #     #     #  #        ###    ");
        System.out.println("       #      #     #     #  #        #  #   ");
        System.out.println(" #     #      #     #     #  #     #  #   #  ");  
        System.out.println("  #####       #      #####    #####   #    # ");
    }
}