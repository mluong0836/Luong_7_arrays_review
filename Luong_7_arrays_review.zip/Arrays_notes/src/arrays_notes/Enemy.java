/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays_notes;

/**
 *
 * @author mluong
 *///2many variables 4me
public class Enemy extends Resources {
    private static int enemyhealth = 400;
    private static int enemyhealth2 = 400;

    public static int getEnemyhealth() {
        return enemyhealth;
    }

    public static void setEnemyhealth(int aEnemyhealth) {
        enemyhealth = aEnemyhealth;
    }

    public static int getEnemyhealth2() {
        return enemyhealth2;
    }

    public static void setEnemyhealth2(int aEnemyhealth2) {
        enemyhealth2 = aEnemyhealth2;
    }
}
