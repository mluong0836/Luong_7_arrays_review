/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays_notes;

    import java.util.Scanner;
    import java.util.Random;
/**
 *
 * @author mluong
 */
public class Luong_7_projects {
  /* DAY 1*/
    static int rows = 48;
    static int columns = 48;
    static String coordinatesX;
    static String coordinatesY;
    static String enter;
    static int numbersX;
    static int numbersY;
    static Scanner recorded = new Scanner(System.in);
    static boolean game;
    static int counter = 1;
    public static int playerhealth = 800;
    public static int damage;
    public static int points = 0;
    static int win = 0;
    static Random rand = new Random();
    static int treasurex = rand.nextInt(48);
    static int treasurey = rand.nextInt(48);
    static int treasure2x = rand.nextInt(48);
    static int treasure2y = rand.nextInt(48);
    static boolean treasure1 = false;
    static boolean treasure2 = false;
    
/******************************************/
     /*          Directions          */
    static boolean N = false;
    static boolean S = false;
    static boolean W = false;
    static boolean E = false;
    static boolean enemyE = false;
    static boolean enemyW = false;
    static boolean enemyS  = false;
    static boolean enemyN = false;
    static boolean enemy2E = false;
    static boolean enemy2W = false;
    static boolean enemy2S  = false;
    static boolean enemy2N = false;
    static boolean enemy3E = false;
    static boolean enemy3W = false;
    static boolean enemy3S  = false;
    static boolean enemy3N = false;
    static boolean enemy4E = false;
    static boolean enemy4W = false;
    static boolean enemy4S  = false;
    static boolean enemy4N = false;
    
/*******************************************/
    
 /******************************************/
    /*             Enemies              */
    static int enemyx = rand.nextInt(48);
    static int enemyy = rand.nextInt(48);
    static int enemy2x = rand.nextInt(20);
    static int enemy2y = rand.nextInt(20);
    static int enemy3x = numbersX + 8;
    static int enemy3y = numbersY + 8;
    static int enemy4x = numbersX - 8;
    static int enemy4y = numbersY - 8;
    static int movement;
 /******************************************/
    
 /******************************************/
    /*       TRAPS FOR MY GAME          */
    static int trapsX = rand.nextInt(48);
    static int trapsY = rand.nextInt(48);
    static int traps2x = rand.nextInt(48);
    static int traps2y = rand.nextInt(48);
    static int traps3x = rand.nextInt(48);
    static int traps3y = rand.nextInt(48);
    static int traps4x = rand.nextInt(48);
    static int traps4y = rand.nextInt(48);
    static int traps5x = rand.nextInt(48);
    static int traps5y = rand.nextInt(48);
    static int traps6X = rand.nextInt(48);
    static int traps6Y = rand.nextInt(48);
    static int traps7x = rand.nextInt(48);
    static int traps7Y = rand.nextInt(48);
    static int traps8x = rand.nextInt(48);
    static int traps8y = rand.nextInt(48);
    static int traps9x = rand.nextInt(48);
    static int traps9y = rand.nextInt(48);
    static int traps10x = rand.nextInt(48);
    static int traps10y = rand.nextInt(48);
  
 /*******************************************/   
   
 /*******************************************/
    /*        Inventory Objects         */
    public static int inventorycheckx = 15;
    public static int inventorychecky = 35; 
    public static int inventorycheck2x = 5;
    public static int inventorycheck2y = 40;
    public static int inventorycheck3x = 40;
    public static int inventorycheck3y = 5;
    public static int inventorycheck4x = 40;
    public static int inventorycheck4y = 40;
    
 /*******************************************/
    
 /*******************************************/
    /*             Weapons             */
    //quadrant 2
    public static int spearx;
    public static int speary; 
    //quadrant 3
    public static int bladex;
    public static int bladey;
    //quadrant 1
    public static int riflex;
    public static int rifley;
    //quadrant 4 
    public static int knifex;
    public static int knifey;
 /*******************************************/
    
    public static Resources resources; //object from different classes
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        game = true;
        while(game) {
            gameplay();
        }
    }
    
      static void gameplay() {
        if(counter == 1) {
            Resources.intro();
            spawningweapons();
            System.out.println("Please choose a coordinate that will fit on a");
            System.out.println("48 by 48 grid.");
            System.out.println("Choose an x coordinate...");
            coordinatesX = recorded.nextLine();
            numbersX = Integer.valueOf(coordinatesX);
            System.out.println("Choose a y coordinate...");
            coordinatesY = recorded.nextLine();
            numbersY = Integer.valueOf(coordinatesY);
        } else if(counter < 1) {
            day2();
        } 
        
        Resources.weapons();
        checkingenemyboundaries();
        enemymovements();
        
        char[][] a = new char[rows][columns];
        
        wallchecking();
      
         for(int i = 0; i < rows; i++) {
            for(int j = 0; j < columns; j++) {
                if(i == numbersX && j == numbersY) {
                    System.out.print(a[numbersX][numbersY] + "@");
                } else if(i == inventorycheckx && j == inventorychecky) {
                    System.out.print(a[inventorycheckx][inventorychecky] + "i");
                } else if(i == inventorycheck2x && j == inventorycheck2y) {
                    System.out.print(a[inventorycheck2x][inventorycheck2y] + "i");
                } else if(i == inventorycheck3x && j == inventorycheck3y) {
                    System.out.print(a[inventorycheck3x][inventorycheck3y] + "i");
                } else if(i == inventorycheck4x && j == inventorycheck4y) {
                    System.out.print(a[inventorycheck4x][inventorycheck4y] + "i");
                } else if(i == knifex && j == knifey && !Resources.knife) {
                    System.out.print(a[knifex][knifey] + "K");
                } else if(i == bladex && j == bladey && !Resources.blade) {
                    System.out.print(a[bladex][bladey] + "B");
                } else if(i == riflex && j == rifley && !Resources.rifle) {
                    System.out.print(a[riflex][rifley] + "R");
                } else if(i == spearx && j == speary && !Resources.spear) {
                    System.out.print(a[spearx][speary] + "S");
                } else if(i == enemyx && j == enemyy) { 
                    System.out.print(a[enemyx][enemyy] + "!");
                } else if(i == enemy2x && j == enemy2y) {
                    System.out.print(a[enemy2x][enemy2y] + "#");
                } else if(i == enemy3x && j == enemy3y) {
                    System.out.print(a[enemy3x][enemy3y] + "$");
                } else if(i == enemy4x && j == enemy4y) {
                    System.out.print(a[enemy4x][enemy4y] + "&");
                } else if(i == trapsX && j == trapsY) {
                    System.out.print(a[trapsX][trapsY] + "1");
                } else if(i == traps2x && j == traps2y) {
                    System.out.print(a[traps2x][traps2y] + "2");
                } else if(i == traps3x && j == traps3y) {
                    System.out.print(a[traps3x][traps3y] + "3");
                } else if(i == traps4x && j == traps4y) {
                    System.out.print(a[traps4x][traps4y] + "4");
                } else if(i == traps5x && j == traps5y) {
                    System.out.print(a[traps5x][traps5y] + "5");
                } else if(i== traps6X && j == traps6Y) {
                    System.out.print(a[traps6X][traps6Y] + "6");
                } else if(i == traps7x && j == traps7Y) {
                    System.out.print(a[traps7x][traps7Y] + "7");
                } else if(i == traps8x && j == traps8y) {
                    System.out.print(a[traps8x][traps8y] + "8");
                } else if(i == traps9x && j == traps9y) {
                    System.out.print(a[traps9x][traps9y] + "9");
                } else if(i == traps10x && j == traps10y) {
                    System.out.print(a[traps10x][traps10y] + "0");
                } else if(i == treasurex && j == treasurey) {
                    System.out.print(a[treasurex][treasurey] + "T");
                } else if(i == treasure2x && j == treasure2y) {
                    System.out.print(a[treasure2x][treasure2y] + "p");
                } else {
                    System.out.print(a[i][j] + ".");
                }
            }
            System.out.println(""); 
        }
         
         Resources.inventorycheckup();
         enemymovementbounds();
         determination();
         traps();
         counter--;
    }
    
    static void day2() {
        System.out.println("Where do you want go.");
        enter = recorded.nextLine();
        System.out.println("N, S, E, W, SW, SE, NW, or NE");
        enter = recorded.nextLine();
        if(enter.contains("NW")) {
            NW();
        } else if(enter.contains("NE")) {
            NE();
        } else if(enter.contains("SW")) {
            SW();
        } else if(enter.contains("SE")) {
            SE();
        } else if(enter.contains("N")) {
            N();
        } else if(enter.contains("S")) {
            S();
        } else if(enter.contains("E")) {
            E();
        } else if(enter.contains("W")) {
            W();
        }
    }
    
    static void N() {
        N = true;
        S = false;
        E = false;
        W = false;
        numbersX--;
    }
    
    static void S() {
        N = false;
        S = true;
        E = false;
        W = false;
        numbersX++;
    }
    
    static void W() {
        N = false;
        S = false;
        E = false;
        W = true;
        numbersY--;
    }
    
    static void E() {
        N = false;
        S = false;
        E = true;
        W = false;
        numbersY++;
    }
    
    static void NE() {
        N = true;
        S = false;
        E = false;
        W = false;
        numbersX--;
        numbersY++;
    }
    
    static void NW() {
        N = true;
        S = false;
        E = false;
        W = false;
        numbersX--;
        numbersY--;
    }
    
    static void SE() {
        N = false;
        S = true;
        E = false;
        W = false;
        numbersX++;
        numbersY++;
    }
    
    static void SW() {
        N = false;
        S = true;
        E = false;
        W = false;
        numbersX++;
        numbersY--;
    }
    
    static void traps() {
        if(numbersX == trapsX && numbersY == trapsY) {
            System.out.println("You fell in a pit!");
            game = false;
        } else if(numbersX == traps2x && numbersY == traps2y) {
            System.out.println("You got crushed by a moving boulder!");
            game = false;
        } else if(numbersX == traps3x && numbersY == traps3y) {
            System.out.println("You get electrocuted near a stream!");
            game = false;
        } else if(numbersX == traps4x && numbersY == traps4y) {
            System.out.println("A meteor landed on you!");
            game = false;
        } else if(numbersX == traps5x && numbersY == traps5y) {
            System.out.println("You got shot down by a squadron!");
            game = false;
        } else if(numbersX == traps6X && numbersY == traps6Y) {
            System.out.println("You stepped on a control Z panel!");
            game = false;
        } else if(numbersX == traps7x && numbersY == traps7Y) {
            System.out.println("You stepped on a spike!");
            damage = rand.nextInt(51);
            System.out.println("The player lost " + damage + " HP.\n");
            playerhealth = playerhealth - damage - 30; // 30 to 80
            System.out.println("Player now has " + playerhealth + " HP left.");
        } else if(numbersX == traps8x && numbersY == traps8y) {
            System.out.println("Meteor incoming!");
            damage = rand.nextInt(51);
            System.out.println("The player lost " + damage + " HP.\n");
            playerhealth = playerhealth - damage - 40; // 40 to 90
            System.out.println("Player now has " + playerhealth + " HP left.");
        } else if(numbersX == traps9x && numbersY == traps9y) {
            System.out.println("Execution by a squadron!");
            damage = rand.nextInt(51);
            System.out.println("The player lost " + damage + " HP.\n");
            playerhealth = playerhealth - damage - 20; // 20 to 70
            System.out.println("Player now has " + playerhealth + " HP left.");
        } else if(numbersX == traps10x && numbersY == traps10y) {
            System.out.println("Incoming boulder...");
            damage = rand.nextInt(51);
            System.out.println("The player lost " + damage + " HP.\n");
            playerhealth = playerhealth - damage - 10; // 10 50 60 HP
            System.out.println("Player now has " + playerhealth + " HP left.");
        }
    }
    
    static void win() {
        Resources.wintext();//win ascii art
        System.out.println("You have found the treasure boxes!\n\n\n");
        System.out.println("YOU WIN!\n\n\n");
        System.out.println("Lets see how many lucky points you've gotten...\n");
        Resources.timer(3000);
        Resources.pointsystem();
        System.out.println("Do you want to replay the game again?");
        enter = recorded.nextLine();
        if(enter.contains("Y") || enter.contains("y")) {
            counter = 1;//resets the game
            game = true;
        } else if(enter.contains("N") || enter.contains("n")) {
            System.out.println("Thank you for playing!\n\n\n");
            game = false;
        }
    }
    
    static void lose() {
        System.out.println("OH NO! The red coats caught you!");
        Resources.losetext();// lose text banner
        game = false;
    }
    
    static void determination() {
        if(numbersX == treasurex && numbersY == treasurey && !treasure1) {
            System.out.println("You grabbed a treasure box\n");
            win = rand.nextInt(40) + 40;
            points = points + win;
            treasure1 = true;
        }else if(numbersX == treasure2x && numbersY == treasure2y && !treasure2) {
            System.out.println("You grabbed a treasure box\n");
            win = rand.nextInt(40) + 40;
            points = points + win;
            treasure2 = true;
        } else if(numbersX == enemyx && numbersY == enemyy) {
            // teleport
            System.out.println("The black coats found you! \n\n");
            Resources.attacking(); // method to fight
            System.out.println("The black coats teleported you somewhere else!\n\n\n");
            numbersX = rand.nextInt(48);
            numbersY = rand.nextInt(48);
        } else if(numbersX == enemy2x && numbersY == enemy2y) {
            // lose
            lose();
        } else if(numbersX == enemy3x && numbersY == enemy3y) {
            // teleport
            System.out.println("The black coats found you!\n\n");
            Resources.attacking(); // method to fight
            System.out.println("They teleported you somewhere else!\n");
            numbersX = rand.nextInt(48);
            numbersY = rand.nextInt(48);
        } else if(numbersX == enemy4x && numbersY == enemy4y) {
            // lose
            lose();
        } else if(playerhealth <= 0) {
            //lose
            lose();
        }
        
        if(treasure1 && treasure2) {
            win();
        }
    }
    
    static void wallchecking() {
        if(numbersX == -1) {
            numbersX++;
            System.out.println("You can't go there!");
        } else if(numbersX == 48) {
            numbersX--;
            System.out.println("You can't go there!");
        } 
        
        if(numbersY == -1) {
            numbersY++;
            System.out.println("You can't go there");
        } else if(numbersY == 48) {
            numbersY--;
            System.out.println("You can't go there!");
        }
    }
    
    static void checkingenemyboundaries() {
        //enemy 1 x coordinates
        if(enemyx < 0) {
            enemyx = 0;
        } else if(enemyx >= 48) {
            enemyx = 47;
        }
        
        //enemy 1 y coordinates
        if(enemyy < 0) {
            enemyy = 0;
        } else if(enemyy >= 48) {
            enemyy = 47;
        }
        
        //enemy 2 x coordinates
        if(enemy2x < 0) {
            enemy2x = 0;
        } else if(enemy2x >= 48) {
            enemy2x = 47;
        }
        
        //enemy 2 y coordinates
        if(enemy2y < 0) {
            enemy2y = 0;
        } else if(enemy2y >= 48) {
            enemy2y = 47;
        }
        
        //enemy 3 x coordinates
        if(enemy3x < 0) {
            enemy3x = 0;
        } else if(enemy3x > 48) {
            enemy3x = 47;
        }
        
        //enemy 3 y coordinates
        if(enemy3y < 0) {
            enemy3y = 0;
        } else if(enemy3y >= 48) {
            enemy3y = 47;
        }
        
        //enemy 4 x coordinates
        if(enemy4x < 0) {
            enemy4x = 0;
        } else if(enemy4x >= 48) {
            enemy4x = 47;
        }
        
        //enemy 4 y coordinates
        if(enemy4y < 0) {
            enemy4y = 0;
        } else if(enemy4y >= 48) {
            enemy4y = 47;
        }
    }
    
    static void enemymovements() {
        
        /* don't worry about zeros for now
        consider that enemy might not move if zero movement*/
        
        // enemy 1 row coordinate
        if(numbersX - enemyx > 0) { // player is below
            movement = rand.nextInt(2) + 1;// prevents movement of zero
            enemyx = enemyx + movement;
            enemyS = true;//enemy moving down
            enemyN = false;
            enemyE = false;
            enemyW = false;
        } else if(numbersX - enemyx < 0) { // player is above 
            movement = rand.nextInt(2) + 1;
            enemyx = enemyx - movement;
            enemyN = true; //enemymoving up
            enemyS = false;
            enemyW = false;
            enemyE = false;
        } 
        
        // enemy 1 column coordinates
        if(numbersY - enemyy > 0) { // player is to the right 
            movement = rand.nextInt(2) + 1;
            enemyy = enemyy + movement;
            enemyE = true;// enemy is moving east
            enemyW = false;
            enemyN = false;
            enemyS = false;
        } else if(numbersY - enemyy < 0) { // player is to the left
            movement = rand.nextInt(2) + 1;
            enemyy = enemyy - movement;
            enemyW = true; //enemy moving west
            enemyE = false;
            enemyN = false;
            enemyS = false;
        }
        
        // enemy 2 row coordinates
        if(numbersX - enemy2x > 0) { // player is below
            movement = rand.nextInt(3) + 1;
            enemy2x = enemy2x + movement;
            enemy2S =  true;//enemy moving down
            enemy2N = false;
            enemy2W = false;
            enemy2E = false;
        } else if(numbersX - enemy2x < 0) { // player is above 
            movement = rand.nextInt(3) + 1;
            enemy2x = enemy2x - movement;
            enemy2N = true;//enemy moving up
            enemy2S = false;
            enemy2E = false;
            enemy2W = false;
        } 
        
        // enemy 2 column coordinates
        if(numbersY - enemy2y > 0) { // player is to the right 
            movement = rand.nextInt(3) + 1; 
            enemy2y = enemy2y + movement;
            enemy2E = true;//enemy moving east
            enemy2S = false;
            enemy2N = false;
            enemy2W = false;
        } else if(numbersY - enemy2y < 0) { // player is to the left
            movement = rand.nextInt(3) + 1;
            enemy2y = enemy2y - movement;
            enemy2W = true;
            enemy2E = false;
            enemy2N = false;
            enemy2S = false;
        }
        
        // enemy 3 row coordinates
        if(numbersX - enemy3x > 0) { // player is below
            movement = rand.nextInt(4) + 1;
            enemy3x = enemy3x + movement;
            enemy3S = true;//enemy is moving down
            enemy3W = false;
            enemy3E = false;
            enemy3N = false;
        } else if(numbersX - enemy3x < 0) { // player is above 
            movement = rand.nextInt(4) + 1;
            enemy3x = enemy3x - movement;
            enemy3N = true; //enemy moving north
            enemy3W = false;
            enemy3E = false;
            enemy3S = false;
        } 
        
        // enemy 3 column coordinates
        if(numbersY - enemy3y > 0) { // player is to the right 
            movement = rand.nextInt(4) + 1;
            enemy3y = enemy3y + movement;
            enemy3E = true;
            enemy3W = false;
            enemy3N = false;
            enemy3S = false;
        } else if(numbersY - enemy3y < 0) { // player is to the left
            movement = rand.nextInt(4) + 1;
            enemy3y = enemy3y - movement;
            enemy3W = true;
            enemy3E = false;
            enemy3N = false;
            enemy3S = false;
        }
        
        // enemy 4 row coordinates
        if(numbersX - enemy4x > 0) { // player is below
            movement = rand.nextInt(6) + 1;
            enemy4x = enemy4x + movement;
            enemy4S = true;
            enemy4W = false;
            enemy4E = false;
            enemy4N = false;
        } else if(numbersX - enemy4x < 0) { // player is above 
            movement = rand.nextInt(6) + 1;
            enemy4x = enemy4x - movement;
            enemy4N = true;
            enemy4W = false;
            enemy4E = false;
            enemy4S = false;
        } 
        
        // enemy 4 column coordinates
        if(numbersY - enemy4y > 0) { // player is to the right 
            movement = rand.nextInt(6) + 1;
            enemy4y = enemy4y + movement;
            enemy4E = true;
            enemy4W = false;
            enemy4N = false;
            enemy4S = false;
        } else if(numbersY - enemy4y < 0) { // player is to the left
            movement = rand.nextInt(6) + 1;
            enemy4y = enemy4y - movement;
            enemy4W = true;
            enemy4E = false;
            enemy4N = false;
            enemy4S = false;
        }
        
       
        enemymovementbounds(); // in case enemy moves out of bounds
    }
    
    static void enemymovementbounds() {
        // enemy 1 row 
        if(enemyx < 0) {
            enemyx = 0;
            movement = rand.nextInt(2) + 1;
            enemyx = movement + enemyx;
            enemyS = true;
            enemyW = false;
            enemyE = false;
            enemyN = false;
        } else if(enemyx >= 48) {
            enemyx = 47;
            movement = rand.nextInt(2) + 1;
            enemyx = movement - enemyx;
            enemyN = true;
            enemyW = false;
            enemyE = false;
            enemyS = false;
        }
        
        // enemy 1 column
        if(enemyy < 0) {
            enemyy = 0;
            movement = rand.nextInt(2) + 1;
            enemyy = movement + enemyy;
            enemyE = true;
            enemyN = false;
            enemyW = false;
            enemyS = false;
        } else if(enemyy >= 48) {
            enemyy = 47;
            movement = rand.nextInt(2) + 1;
            enemyy = enemyy - movement;
            enemyW = true;
            enemyN = false;
            enemyE = false;
            enemyS = false;
        }
        
        // enemy 2 row
        if(enemy2x < 0) {
            enemy2x = 0;
            movement = rand.nextInt(2) + 1;
            enemy2x = movement + enemy2x;
            enemy2S = true;
            enemy2N = false;
            enemy2W = false;
            enemy2E = false;
        } else if(enemy2x >= 48) {
            enemy2x = 47;
            movement = rand.nextInt(2) + 1;
            enemy2x = enemy2x - movement;
            enemy2N = true;
            enemy2W = false;
            enemy2E = false;
            enemy2S = false;
        }
        
        // enemy 2 column
        if(enemy2y < 0) {
            enemy2y = 0;
            movement = rand.nextInt(2) + 1;
            enemy2y = movement + enemy2y;
            enemy2W = true;
            enemy2N = false;
            enemy2E = false;
            enemy2S = false;
        } else if(enemy2y >= 48) {
            enemy2y = 47;
            movement = rand.nextInt(2) + 1;
            enemy2y = enemy2y - movement;
            enemy2E = true;
            enemy2N = false;
            enemy2W = false;
            enemy2S = false;
        }
        
        // enemy 3 row
        if(enemy3x < 0) {
            enemy3x = 0;
            movement = rand.nextInt(2) + 1;
            enemy3x = movement + enemy3x;
            enemy3E = true;
            enemy3N = false;
            enemy3W = false;
            enemy3S = false;
        } else if(enemy3x >= 48) {
            enemy3x = 47;
            movement = rand.nextInt(2) + 1;
            enemy3x = enemy3x - movement;
            enemy3W = true;
            enemy3N = false;
            enemy3E = false;
            enemy3S = false;
        }
        
        // enemy 3 column
        if(enemy3y < 0) {
            enemy3y = 0;
            movement = rand.nextInt(2) + 1;
            enemy3y = movement + enemy3y;
            enemy3E = true;
            enemy3N = false;
            enemy3W = false;
            enemy3S = false;
        } else if(enemy3y >= 48) {
            enemy3y = 47;
            movement = rand.nextInt(2) + 1;
            enemy3y = enemy3y - movement;
            enemy3W = true;
            enemy3N = false;
            enemy3E = false;
            enemy3S = false;
        }
        
        // enemy 4 row
        if(enemy4x < 0) {
            enemy4x = 0;
            movement = rand.nextInt(2) + 1;
            enemy4x = movement + enemy4x;
            enemy4S = true;
            enemy4N = false;
            enemy4W = false;
            enemy4E = false;
        } else if(enemy4x >= 48) {
            enemy4x = 47;
            movement = rand.nextInt(2) + 1;
            enemy4x = enemy4x - movement;
            enemy4N = true;
            enemy4W = false;
            enemy4E = false;
            enemy4S = false;
        }
        
        // enemy 4 column
        if(enemy4y < 0) {
            enemy4y = 0;
            movement = rand.nextInt(2) + 1;
            enemy4y = movement + enemy4y;
            enemy4E = true;
            enemy4N = false;
            enemy4W = false;
            enemy4S = false;
        } else if(enemy4y >= 48) {
            enemy4y = 47;
            movement = rand.nextInt(2) + 1;
            enemy4y = enemy4y - movement;
            enemy4W = true;
            enemy4N = false;
            enemy4E = false;
            enemy4S = false;
        }
    }
    
    static void spawningweapons() {
        //quadrant 2
        spearx = rand.nextInt(21);
        speary = rand.nextInt(21);
        //quadrant 3
        bladex = rand.nextInt(21) + 27;
        bladey = rand.nextInt(21);
        //quadrant 1
        riflex = rand.nextInt(21);
        rifley = rand.nextInt(21) + 27;
        //quadrant 4 
        knifex = rand.nextInt(21) + 27;
        knifey = rand.nextInt(21) + 27;
    }
}

/******************************************************************************/
                        /* DAY 1 (PLAIN X) */
/*
        System.out.println("Please choose a coordinate that will fit on a");
        System.out.println("10 by 10 grid.");
        System.out.println("Choose an x coordinate...");
        coordinatesX = recorded.nextLine();
        numbersX = Integer.valueOf(coordinatesX);
        System.out.println("Choose a y coordinate...");
        coordinatesY = recorded.nextLine();
        numbersY = Integer.valueOf(coordinatesY);

        char[][] a = new char[rows][columns];
        //a[0][0] = "X";
        
         for(int i = 0; i < rows; i++) {
            for(int j = 0; j < columns; j++) {
                if(i == numbersX && j == numbersY) {
                    System.out.print(a[numbersX][numbersY] + "X");
                }else {
                    System.out.print(a[i][j] + ".");
                }
            }
            System.out.println("");
        }
*/
/******************************************************************************/
